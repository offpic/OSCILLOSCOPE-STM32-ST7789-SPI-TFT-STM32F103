# DIY-Oscilloscope-base-Bluepill

Video XY mode:
https://www.youtube.com/watch?v=3I3FFp_iAn0
Normal mode:
https://www.youtube.com/watch?v=sSbzYbYM4iM

